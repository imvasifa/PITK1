import psycopg2
import bcrypt

def check_user_credentials(username, password):
    conn = None
    cur = None
    try:
        # Connect to the database
        conn = psycopg2.connect(
            dbname="pitk",
            user="pitk_user",
            password="N63uWAQkpdSDg8SFvoggKxCDw5OY1aPx",
            host="dpg-d1efmamuk2gs73allkt0-a.singapore-postgres.render.com",
            port="5432"
        )
        cur = conn.cursor()
        
        # Query the user
        cur.execute("""
            SELECT 
                id, 
                user_data->'account'->>'username' as username,
                user_data->'account'->>'password' as password_hash
            FROM users 
            WHERE user_data->'account'->>'username' = %s
        """, (username,))
        
        user_data = cur.fetchone()
        
        if not user_data:
            print(f"❌ User '{username}' not found in the database.")
            return False
            
        # Convert to dictionary
        columns = [desc[0] for desc in cur.description]
        user_dict = dict(zip(columns, user_data))
        
        print(f"✅ Found user: {user_dict['username']} (ID: {user_dict['id']})")
        print(f"🔑 Password hash: {user_dict['password_hash'][:20]}...")
        
        # Verify password
        if bcrypt.checkpw(password.encode('utf-8'), user_dict['password_hash'].encode('utf-8')):
            print("✅ Password is correct!")
            return True
        else:
            print("❌ Incorrect password")
            return False
            
    except Exception as e:
        print(f"❌ Error checking user: {str(e)}")
        return False
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    username = "imjjrobo"
    password = "ccc"
    print(f"🔍 Checking credentials for user: {username}")
    check_user_credentials(username, password)
